import React, { Component } from "react";
import "./styles.css";
import { List } from "./List";
import { Form } from "./Form";

export default class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      todos: [
        { text: "Do the laundry" },
        { text: "Iron the clothes" },
        { text: "Go for a walk" }
      ],
      newTodoText: ""
    };
  }

  handleAdd = () => {
    const { todos, newTodoText } = this.state;
    if (newTodoText.trim() !== "") {
      const newTodo = { text: newTodoText };
      this.setState({
        todos: [...todos, newTodo],
        newTodoText: "" 
      });
    }
  };

  handleChange = (event) => {
    this.setState({ newTodoText: event.target.value });
  };

  handleRemove = (index) => {
    const updatedTodos = [...this.state.todos];
    updatedTodos.splice(index, 1);
    this.setState({ todos: updatedTodos });
  };

  render() {
    const { todos, newTodoText } = this.state;
    return (
      <div className="App">
        <h1>Todo List</h1>
        <Form
          newTodoText={newTodoText}
          handleChange={this.handleChange}
          handleAdd={this.handleAdd}
        />
        <List todos={todos} handleRemove={this.handleRemove} />
      </div>
    );
  }
}
