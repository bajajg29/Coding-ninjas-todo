import React, { Component } from "react";

export class Form extends Component {
  render() {
    const { newTodoText, handleChange, handleAdd } = this.props;

    return (
      <div className="form">
        <input
          type="text"
          value={newTodoText}
          onChange={handleChange}
          placeholder="What's on your mind?"
          required
        />
        <button onClick={handleAdd}>Add</button>
      </div>
    );
  }
}
